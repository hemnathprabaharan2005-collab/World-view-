/* WORLDVIEW - main script
   Handles: theme, language, mobile menu, global search, shared helpers.
   Feature modules (countries.js, history.js, news.js) load after this file
   and use the shared object window.WV. */

/* ---------- Shared helpers ---------- */
function safeGet(key) {
  try { return localStorage.getItem(key); } catch (e) { return null; }
}
function safeSet(key, value) {
  try { localStorage.setItem(key, value); } catch (e) { /* ignore */ }
}

const root = document.documentElement;
let currentLang = "en";

function t(key, vars) {
  const dict = TRANSLATIONS[currentLang] || TRANSLATIONS.en;
  let text = dict[key] || TRANSLATIONS.en[key] || key;
  if (vars) {
    Object.keys(vars).forEach(function (k) {
      text = text.replace("{" + k + "}", vars[k]);
    });
  }
  return text;
}

/* h("div", {class: "x"}, "text", childElement) -> builds elements safely
   (uses textContent, so data from the internet can never inject HTML). */
function h(tag, attrs) {
  const el = document.createElement(tag);
  const kids = Array.prototype.slice.call(arguments, 2);
  Object.keys(attrs || {}).forEach(function (k) {
    const v = attrs[k];
    if (v === false || v === null || v === undefined) return;
    if (k === "class") el.className = v;
    else if (k.indexOf("on") === 0) el.addEventListener(k.slice(2), v);
    else el.setAttribute(k, v === true ? "" : v);
  });
  (function add(list) {
    list.forEach(function (c) {
      if (Array.isArray(c)) return add(c);
      if (c === null || c === undefined || c === false) return;
      el.appendChild(c.nodeType ? c : document.createTextNode(String(c)));
    });
  })(kids);
  return el;
}

function langTag() {
  return { en: "en-IN", hi: "hi-IN", ta: "ta-IN", es: "es-ES", fr: "fr-FR" }[currentLang] || "en";
}

window.WV = {
  t: t,
  h: h,
  langTag: langTag,
  searchProviders: [],   // each module adds a function(query) -> [{type, label, go}]
  onLangChange: []       // each module adds a function() to re-draw its text
};

/* ---------- 1. DARK / LIGHT THEME ---------- */
const themeBtn = document.getElementById("theme-toggle");

function applyTheme(theme) {
  root.setAttribute("data-theme", theme);
  safeSet("wv-theme", theme);
}
const savedTheme = safeGet("wv-theme");
const prefersDark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
applyTheme(savedTheme || (prefersDark ? "dark" : "light"));

themeBtn.addEventListener("click", function () {
  applyTheme(root.getAttribute("data-theme") === "dark" ? "light" : "dark");
});

/* ---------- 2. LANGUAGE ---------- */
const langSelect = document.getElementById("lang-select");

function translatePage() {
  document.querySelectorAll("[data-i18n]").forEach(function (el) {
    const key = el.getAttribute("data-i18n");
    const dict = TRANSLATIONS[currentLang] || TRANSLATIONS.en;
    const text = dict[key] || TRANSLATIONS.en[key];
    if (text) el.textContent = text;
  });
  document.querySelectorAll("[data-i18n-placeholder]").forEach(function (el) {
    const dict = TRANSLATIONS[currentLang] || TRANSLATIONS.en;
    const text = dict[el.getAttribute("data-i18n-placeholder")] || TRANSLATIONS.en[el.getAttribute("data-i18n-placeholder")];
    if (text) el.setAttribute("placeholder", text);
  });
}

function applyLanguage(lang) {
  if (!TRANSLATIONS[lang]) lang = "en";
  currentLang = lang;
  root.setAttribute("lang", lang);
  safeSet("wv-lang", lang);
  langSelect.value = lang;
  translatePage();
  window.WV.onLangChange.forEach(function (fn) { fn(); });
  runSearch();
}

langSelect.addEventListener("change", function () {
  applyLanguage(langSelect.value);
});

/* ---------- 3. MOBILE MENU ---------- */
const menuBtn = document.getElementById("menu-toggle");
const mainNav = document.getElementById("main-nav");

menuBtn.addEventListener("click", function () {
  const open = mainNav.classList.toggle("open");
  menuBtn.setAttribute("aria-expanded", open ? "true" : "false");
});
mainNav.querySelectorAll("a").forEach(function (link) {
  link.addEventListener("click", function () {
    mainNav.classList.remove("open");
    menuBtn.setAttribute("aria-expanded", "false");
  });
});

/* ---------- 4. GLOBAL SEARCH ----------
   Highlights matching category cards, and lists matching
   countries and historical events (added by the other modules). */
const searchForm = document.getElementById("search-form");
const searchInput = document.getElementById("search-input");
const searchMessage = document.getElementById("search-message");
const searchResults = document.getElementById("search-results");
const cards = document.querySelectorAll("#category-grid .card");

function runSearch() {
  const q = searchInput.value.trim().toLowerCase();
  let found = 0;

  cards.forEach(function (card) {
    card.classList.remove("match");
    if (!q) return;
    const haystack = (card.textContent + " " + (card.dataset.keywords || "")).toLowerCase();
    if (haystack.indexOf(q) !== -1) { card.classList.add("match"); found++; }
  });

  searchResults.innerHTML = "";
  let items = [];
  if (q.length >= 2) {
    window.WV.searchProviders.forEach(function (provider) {
      items = items.concat(provider(q));
    });
  }

  items.forEach(function (item) {
    const btn = h("button", { type: "button", class: "sr-btn", onclick: function () {
      searchResults.hidden = true;
      item.go();
    } },
      h("span", { class: "sr-tag" }, t(item.type)),
      h("span", { class: "sr-label" }, item.label)
    );
    searchResults.appendChild(h("li", null, btn));
  });
  searchResults.hidden = items.length === 0;
  found += items.length;

  if (!q) searchMessage.textContent = "";
  else if (found === 0) searchMessage.textContent = t("msg_none");
  else searchMessage.textContent = "";
}

searchForm.addEventListener("submit", function (e) { e.preventDefault(); runSearch(); });
searchInput.addEventListener("input", runSearch);

/* Category cards that point to the news section choose the matching news tab */
cards.forEach(function (card) {
  card.addEventListener("click", function () {
    const topic = card.getAttribute("data-news");
    if (topic && window.WV.selectNewsTab) window.WV.selectNewsTab(topic);
  });
});

/* ---------- 5. FOOTER YEAR ---------- */
document.getElementById("year").textContent = new Date().getFullYear();

/* ---------- 6. START ---------- */
applyLanguage(safeGet("wv-lang") || "en");

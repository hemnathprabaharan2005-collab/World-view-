/* WORLDVIEW - Country Explorer
   Data: REST Countries (free, no key). Summaries: Wikipedia REST API (free, no key). */
(function () {
  "use strict";
  const t = WV.t, h = WV.h;

  const API = "https://restcountries.com/v3.1/all?fields=name,cca2,flags,region,subregion,capital,population,area,languages,currencies";
  const PAGE_SIZE = 24;
  const REGIONS = ["Africa", "Americas", "Asia", "Europe", "Oceania", "Antarctic"];

  let allCountries = [];
  let filtered = [];
  let shown = 0;
  let loadState = "loading"; // loading | ready | error

  const grid = document.getElementById("country-grid");
  const status = document.getElementById("country-status");
  const moreBtn = document.getElementById("country-more");
  const searchBox = document.getElementById("country-search");
  const regionSelect = document.getElementById("region-select");
  const statCountries = document.getElementById("stat-countries");
  const dialog = document.getElementById("country-dialog");
  const dialogBody = document.getElementById("dialog-body");

  /* ----- Region dropdown ----- */
  function buildRegionOptions() {
    const current = regionSelect.value || "all";
    regionSelect.innerHTML = "";
    regionSelect.appendChild(h("option", { value: "all" }, t("ce_all_regions")));
    REGIONS.forEach(function (r) {
      regionSelect.appendChild(h("option", { value: r }, t("reg_" + r)));
    });
    regionSelect.value = current;
  }

  /* ----- Load data (cached for the browser session) ----- */
  function loadCountries() {
    loadState = "loading";
    render();
    let cached = null;
    try { cached = JSON.parse(sessionStorage.getItem("wv-countries") || "null"); } catch (e) { /* ignore */ }
    if (cached && cached.length) { return ready(cached); }

    fetch(API)
      .then(function (res) {
        if (!res.ok) throw new Error("HTTP " + res.status);
        return res.json();
      })
      .then(function (data) {
        try { sessionStorage.setItem("wv-countries", JSON.stringify(data)); } catch (e) { /* too big or blocked */ }
        ready(data);
      })
      .catch(function (err) {
        console.warn("Countries failed to load:", err);
        loadState = "error";
        render();
      });
  }

  function ready(data) {
    allCountries = data.slice().sort(function (a, b) {
      return a.name.common.localeCompare(b.name.common);
    });
    statCountries.textContent = allCountries.length;
    loadState = "ready";
    applyFilters();
  }

  /* ----- Filtering ----- */
  function applyFilters() {
    const q = searchBox.value.trim().toLowerCase();
    const region = regionSelect.value;
    filtered = allCountries.filter(function (c) {
      if (region !== "all" && c.region !== region) return false;
      if (!q) return true;
      const text = (c.name.common + " " + c.name.official + " " + (c.capital || []).join(" ")).toLowerCase();
      return text.indexOf(q) !== -1;
    });
    shown = Math.min(PAGE_SIZE, filtered.length);
    render();
  }

  /* ----- Drawing the grid ----- */
  function makeCard(c) {
    return h("button", { type: "button", class: "country-card", onclick: function () { openCountry(c); } },
      h("img", { src: c.flags && c.flags.svg ? c.flags.svg : (c.flags && c.flags.png) || "", alt: (c.flags && c.flags.alt) || ("Flag of " + c.name.common), loading: "lazy", class: "flag" }),
      h("span", { class: "cc-name" }, c.name.common),
      h("span", { class: "cc-sub" }, c.capital && c.capital.length ? c.capital[0] : "—"),
      h("span", { class: "cc-region" }, t("reg_" + c.region) === "reg_" + c.region ? c.region : t("reg_" + c.region))
    );
  }

  function render() {
    grid.innerHTML = "";
    if (loadState === "loading") { status.textContent = t("ce_loading"); moreBtn.hidden = true; return; }
    if (loadState === "error") { status.textContent = t("ce_error"); moreBtn.hidden = true; return; }
    if (!filtered.length) { status.textContent = t("ce_nores"); moreBtn.hidden = true; return; }

    filtered.slice(0, shown).forEach(function (c) { grid.appendChild(makeCard(c)); });
    status.textContent = t("ce_showing", { n: Math.min(shown, filtered.length), total: filtered.length });
    moreBtn.hidden = shown >= filtered.length;
  }

  moreBtn.addEventListener("click", function () {
    shown = Math.min(shown + PAGE_SIZE, filtered.length);
    render();
  });
  searchBox.addEventListener("input", applyFilters);
  regionSelect.addEventListener("change", applyFilters);

  /* ----- Detail dialog ----- */
  function listValues(obj, field) {
    if (!obj) return t("d_na");
    const vals = Object.keys(obj).map(function (k) {
      return field ? obj[k][field] + (obj[k].symbol ? " (" + obj[k].symbol + ")" : "") : obj[k];
    });
    return vals.length ? vals.join(", ") : t("d_na");
  }

  function fact(label, value) {
    return h("div", { class: "fact" }, h("dt", null, label), h("dd", null, value));
  }

  function closeDialog() {
    if (dialog.close) dialog.close(); else dialog.removeAttribute("open");
  }

  function openCountry(c) {
    const wikiTitle = c.name.common.replace(/ /g, "_");
    const wikiPage = "https://en.wikipedia.org/wiki/" + encodeURIComponent(wikiTitle);
    const summaryBox = h("p", { class: "summary" }, t("d_loading"));
    const refList = h("ul", { class: "ref-list" });

    dialogBody.innerHTML = "";
    dialogBody.appendChild(h("button", { type: "button", class: "dialog-close", "aria-label": t("d_close"), onclick: closeDialog }, "✕"));
    dialogBody.appendChild(h("img", { src: (c.flags && (c.flags.svg || c.flags.png)) || "", alt: (c.flags && c.flags.alt) || ("Flag of " + c.name.common), class: "dialog-flag" }));
    dialogBody.appendChild(h("h3", { id: "dlg-title" }, c.name.common));
    dialogBody.appendChild(h("p", { class: "official" }, c.name.official));

    dialogBody.appendChild(h("dl", { class: "facts" },
      fact(t("d_capital"), c.capital && c.capital.length ? c.capital.join(", ") : t("d_na")),
      fact(t("d_region"), [c.region ? t("reg_" + c.region) : "", c.subregion || ""].filter(Boolean).join(" · ") || t("d_na")),
      fact(t("d_population"), typeof c.population === "number" ? c.population.toLocaleString(WV.langTag()) : t("d_na")),
      fact(t("d_area"), typeof c.area === "number" ? c.area.toLocaleString(WV.langTag()) + " km²" : t("d_na")),
      fact(t("d_languages"), listValues(c.languages)),
      fact(t("d_currencies"), listValues(c.currencies, "name"))
    ));

    dialogBody.appendChild(h("h4", null, t("d_about")));
    dialogBody.appendChild(summaryBox);
    dialogBody.appendChild(h("h4", null, t("d_refs")));
    dialogBody.appendChild(refList);
    refList.appendChild(h("li", null, h("a", { href: "https://restcountries.com", target: "_blank", rel: "noopener" }, "REST Countries"), " – " + t("d_capital") + ", " + t("d_population") + ", " + t("d_area")));

    if (dialog.showModal) { if (!dialog.open) dialog.showModal(); } else { dialog.setAttribute("open", ""); }

    fetch("https://en.wikipedia.org/api/rest_v1/page/summary/" + encodeURIComponent(wikiTitle))
      .then(function (res) {
        if (!res.ok) throw new Error("HTTP " + res.status);
        return res.json();
      })
      .then(function (data) {
        if (data.type !== "standard" || !data.extract) throw new Error("no usable summary");
        summaryBox.textContent = data.extract;
        const when = new Date().toLocaleDateString(WV.langTag(), { year: "numeric", month: "long", day: "numeric" });
        const pageUrl = (data.content_urls && data.content_urls.desktop && data.content_urls.desktop.page) || wikiPage;
        refList.appendChild(h("li", null,
          h("a", { href: pageUrl, target: "_blank", rel: "noopener" }, "Wikipedia – " + (data.title || c.name.common)),
          " (" + t("d_retrieved") + ": " + when + ")"
        ));
      })
      .catch(function () {
        summaryBox.textContent = t("d_nosummary");
        refList.appendChild(h("li", null, h("a", { href: wikiPage, target: "_blank", rel: "noopener" }, "Wikipedia – " + c.name.common)));
      });
  }

  // Close when clicking the dark backdrop
  dialog.addEventListener("click", function (e) { if (e.target === dialog) closeDialog(); });

  /* ----- Hook into global search and language switching ----- */
  WV.searchProviders.push(function (q) {
    if (loadState !== "ready") return [];
    return allCountries.filter(function (c) {
      return c.name.common.toLowerCase().indexOf(q) !== -1 ||
             (c.capital || []).join(" ").toLowerCase().indexOf(q) !== -1;
    }).slice(0, 6).map(function (c) {
      return { type: "sr_country", label: c.name.common, go: function () {
        document.getElementById("countries").scrollIntoView({ behavior: "smooth" });
        openCountry(c);
      } };
    });
  });

  WV.onLangChange.push(function () {
    buildRegionOptions();
    if (dialog.open) closeDialog();
    render();
  });

  buildRegionOptions();
  loadCountries();
})();

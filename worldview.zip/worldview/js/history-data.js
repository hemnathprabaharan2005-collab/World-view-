/* WORLDVIEW - curated historical events
   RULES FOR ADDING EVENTS:
   1. Only add events you can confirm in a reliable source.
   2. Always include a reference (title + URL).
   3. If a date is traditional or estimated, set approx: true.
   sortYear: negative numbers = BCE (e.g. -776 = 776 BCE). */

window.WV_HISTORY = [
  {
    sortYear: -2560, dateLabel: "c. 2600–2500 BCE", approx: true, era: "ancient",
    title: "Great Pyramid of Giza built",
    text: "The Great Pyramid was built for the pharaoh Khufu during Egypt's Fourth Dynasty. It is the oldest of the Seven Wonders of the Ancient World and the only one still largely standing. Exact construction dates are estimated by historians.",
    ref: { title: "Great Pyramid of Giza – Wikipedia", url: "https://en.wikipedia.org/wiki/Great_Pyramid_of_Giza" }
  },
  {
    sortYear: -776, dateLabel: "776 BCE", approx: true, era: "ancient",
    title: "First recorded ancient Olympic Games",
    text: "The first recorded ancient Olympic Games are traditionally dated to 776 BCE at Olympia, Greece. The date comes from ancient Greek sources and is treated as traditional.",
    ref: { title: "Ancient Olympic Games – Wikipedia", url: "https://en.wikipedia.org/wiki/Ancient_Olympic_Games" }
  },
  {
    sortYear: -509, dateLabel: "509 BCE", approx: true, era: "ancient",
    title: "Roman Republic traditionally founded",
    text: "According to Roman tradition, the monarchy was overthrown in 509 BCE and the Roman Republic began. The date is traditional and the early history is partly legendary.",
    ref: { title: "Roman Republic – Wikipedia", url: "https://en.wikipedia.org/wiki/Roman_Republic" }
  },
  {
    sortYear: -221, dateLabel: "221 BCE", approx: false, era: "ancient",
    title: "Qin unifies China",
    text: "The state of Qin completed its conquest of the rival Warring States. Its king took the title Shi Huangdi, meaning 'First Emperor', beginning imperial China.",
    ref: { title: "Qin Shi Huang – Wikipedia", url: "https://en.wikipedia.org/wiki/Qin_Shi_Huang" }
  },
  {
    sortYear: -27, dateLabel: "27 BCE", approx: false, era: "ancient",
    title: "Augustus becomes first Roman emperor",
    text: "The Roman Senate granted Octavian the title Augustus. Historians commonly treat this as the start of the Roman Empire.",
    ref: { title: "Augustus – Wikipedia", url: "https://en.wikipedia.org/wiki/Augustus" }
  },
  {
    sortYear: 476, dateLabel: "476 CE", approx: false, era: "ancient",
    title: "End of the Western Roman Empire",
    text: "The Germanic leader Odoacer deposed the young emperor Romulus Augustulus. This is the conventional date for the end of the Western Roman Empire; the Eastern (Byzantine) Empire continued.",
    ref: { title: "Fall of the Western Roman Empire – Wikipedia", url: "https://en.wikipedia.org/wiki/Fall_of_the_Western_Roman_Empire" }
  },
  {
    sortYear: 622, dateLabel: "622 CE", approx: false, era: "medieval",
    title: "The Hijra",
    text: "The Prophet Muhammad and his followers migrated from Mecca to Medina. The Islamic (Hijri) calendar counts its years from this event.",
    ref: { title: "Islamic calendar – Wikipedia", url: "https://en.wikipedia.org/wiki/Islamic_calendar" }
  },
  {
    sortYear: 1215, dateLabel: "15 June 1215", approx: false, era: "medieval",
    title: "Magna Carta sealed",
    text: "King John of England agreed to the Magna Carta at Runnymede. It limited royal power and became an important symbol in the history of constitutional law.",
    ref: { title: "Magna Carta – Wikipedia", url: "https://en.wikipedia.org/wiki/Magna_Carta" }
  },
  {
    sortYear: 1453, dateLabel: "29 May 1453", approx: false, era: "medieval",
    title: "Fall of Constantinople",
    text: "Ottoman forces under Sultan Mehmed II captured Constantinople, ending the Byzantine Empire.",
    ref: { title: "Fall of Constantinople – Wikipedia", url: "https://en.wikipedia.org/wiki/Fall_of_Constantinople" }
  },
  {
    sortYear: 1492, dateLabel: "12 October 1492", approx: false, era: "earlymodern",
    title: "Columbus reaches the Americas",
    text: "Christopher Columbus, sailing for the Spanish crown, landed in the Caribbean. His voyages began lasting European contact with the Americas.",
    ref: { title: "Voyages of Christopher Columbus – Wikipedia", url: "https://en.wikipedia.org/wiki/Voyages_of_Christopher_Columbus" }
  },
  {
    sortYear: 1776, dateLabel: "4 July 1776", approx: false, era: "earlymodern",
    title: "United States Declaration of Independence",
    text: "The Second Continental Congress adopted the Declaration of Independence, announcing the separation of thirteen American colonies from Great Britain.",
    ref: { title: "United States Declaration of Independence – Wikipedia", url: "https://en.wikipedia.org/wiki/United_States_Declaration_of_Independence" }
  },
  {
    sortYear: 1789, dateLabel: "14 July 1789", approx: false, era: "earlymodern",
    title: "French Revolution: storming of the Bastille",
    text: "Parisians stormed the Bastille fortress-prison. The event became a symbol of the French Revolution, which reshaped France and influenced politics worldwide.",
    ref: { title: "Storming of the Bastille – Wikipedia", url: "https://en.wikipedia.org/wiki/Storming_of_the_Bastille" }
  },
  {
    sortYear: 1857, dateLabel: "10 May 1857", approx: false, era: "modern",
    title: "Indian Rebellion of 1857 begins",
    text: "A revolt by soldiers began at Meerut against the rule of the British East India Company. After it, the British Crown took direct control of India in 1858.",
    ref: { title: "Indian Rebellion of 1857 – Wikipedia", url: "https://en.wikipedia.org/wiki/Indian_Rebellion_of_1857" }
  },
  {
    sortYear: 1914, dateLabel: "28 July 1914", approx: false, era: "modern",
    title: "World War I begins",
    text: "Austria-Hungary declared war on Serbia a month after the assassination of Archduke Franz Ferdinand. Alliances quickly drew in the major European powers.",
    ref: { title: "World War I – Wikipedia", url: "https://en.wikipedia.org/wiki/World_War_I" }
  },
  {
    sortYear: 1917, dateLabel: "1917", approx: false, era: "modern",
    title: "Russian Revolutions",
    text: "Two revolutions took place in Russia in 1917. The first overthrew Tsar Nicholas II; in the second, the Bolsheviks took power, leading to the creation of the Soviet state.",
    ref: { title: "Russian Revolution – Wikipedia", url: "https://en.wikipedia.org/wiki/Russian_Revolution" }
  },
  {
    sortYear: 1939, dateLabel: "1 September 1939", approx: false, era: "modern",
    title: "World War II begins in Europe",
    text: "Germany invaded Poland. Britain and France declared war on Germany two days later.",
    ref: { title: "World War II – Wikipedia", url: "https://en.wikipedia.org/wiki/World_War_II" }
  },
  {
    sortYear: 1945, dateLabel: "2 September 1945", approx: false, era: "modern",
    title: "World War II ends",
    text: "Japan signed the formal instrument of surrender aboard the USS Missouri, ending World War II. Germany had surrendered in May 1945.",
    ref: { title: "World War II – Wikipedia", url: "https://en.wikipedia.org/wiki/World_War_II" }
  },
  {
    sortYear: 1945.8, dateLabel: "24 October 1945", approx: false, era: "contemporary",
    title: "United Nations comes into existence",
    text: "The UN Charter came into force after ratification by the major powers and a majority of other signatories. The UN was created to maintain international peace and security.",
    ref: { title: "United Nations – Wikipedia", url: "https://en.wikipedia.org/wiki/United_Nations" }
  },
  {
    sortYear: 1947, dateLabel: "15 August 1947", approx: false, era: "contemporary",
    title: "Independence of India and Pakistan",
    text: "British India was divided and two independent dominions, India and Pakistan, were created. The partition involved large-scale migration and violence.",
    ref: { title: "Partition of India – Wikipedia", url: "https://en.wikipedia.org/wiki/Partition_of_India" }
  },
  {
    sortYear: 1969, dateLabel: "20 July 1969", approx: false, era: "contemporary",
    title: "Apollo 11 lands on the Moon",
    text: "NASA's Apollo 11 lunar module landed on the Moon. Neil Armstrong became the first person to walk on its surface.",
    ref: { title: "Apollo 11 – Wikipedia", url: "https://en.wikipedia.org/wiki/Apollo_11" }
  },
  {
    sortYear: 1989, dateLabel: "9 November 1989", approx: false, era: "contemporary",
    title: "Fall of the Berlin Wall",
    text: "East Germany opened its border crossings and crowds began to dismantle the Berlin Wall. Germany was formally reunified on 3 October 1990.",
    ref: { title: "Berlin Wall – Wikipedia", url: "https://en.wikipedia.org/wiki/Berlin_Wall" }
  },
  {
    sortYear: 1991, dateLabel: "July 1991", approx: false, era: "contemporary",
    title: "India launches major economic reforms",
    text: "Facing a balance-of-payments crisis, India's government under Prime Minister P. V. Narasimha Rao, with Finance Minister Manmohan Singh, began liberalising the economy. The reforms reduced licensing controls and opened the economy to foreign trade and investment.",
    ref: { title: "Economic liberalisation in India – Wikipedia", url: "https://en.wikipedia.org/wiki/Economic_liberalisation_in_India" }
  },
  {
    sortYear: 1991.9, dateLabel: "26 December 1991", approx: false, era: "contemporary",
    title: "Dissolution of the Soviet Union",
    text: "The Soviet Union formally ceased to exist, leaving fifteen independent republics. This ended the Cold War era.",
    ref: { title: "Dissolution of the Soviet Union – Wikipedia", url: "https://en.wikipedia.org/wiki/Dissolution_of_the_Soviet_Union" }
  },
  {
    sortYear: 2008, dateLabel: "15 September 2008", approx: false, era: "contemporary",
    title: "Lehman Brothers files for bankruptcy",
    text: "The US investment bank Lehman Brothers filed for bankruptcy, a key moment in the global financial crisis of 2007–2009 that affected banking systems and economies worldwide.",
    ref: { title: "Bankruptcy of Lehman Brothers – Wikipedia", url: "https://en.wikipedia.org/wiki/Bankruptcy_of_Lehman_Brothers" }
  }
];

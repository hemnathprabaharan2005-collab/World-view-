/* WORLDVIEW - interactive history timeline
   Reads events from window.WV_HISTORY (js/history-data.js). */
(function () {
  "use strict";
  const t = WV.t, h = WV.h;

  const ERAS = ["ancient", "medieval", "earlymodern", "modern", "contemporary"];
  const events = (window.WV_HISTORY || []).slice().sort(function (a, b) { return a.sortYear - b.sortYear; });
  let activeEra = "all";

  const list = document.getElementById("timeline");
  const filters = document.getElementById("era-filters");
  document.getElementById("stat-events").textContent = events.length;

  function drawFilters() {
    filters.innerHTML = "";
    ["all"].concat(ERAS).forEach(function (era) {
      filters.appendChild(h("button", {
        type: "button",
        class: "chip" + (era === activeEra ? " active" : ""),
        "aria-pressed": era === activeEra ? "true" : "false",
        onclick: function () { activeEra = era; drawFilters(); drawTimeline(); }
      }, t("era_" + era)));
    });
  }

  function drawTimeline(openIndex) {
    list.innerHTML = "";
    events.forEach(function (ev, i) {
      if (activeEra !== "all" && ev.era !== activeEra) return;

      const details = h("details", { class: "event", id: "ev-" + i },
        h("summary", null,
          h("span", { class: "ev-date" }, ev.dateLabel),
          h("span", { class: "ev-title" }, ev.title)
        ),
        h("div", { class: "ev-body" },
          h("p", null, ev.text),
          h("p", { class: "ev-meta" },
            h("span", { class: "badge badge-verified" }, t("hist_verified")),
            ev.approx ? h("span", { class: "badge badge-approx" }, t("hist_approx")) : null
          ),
          h("p", { class: "ev-ref" }, t("hist_ref") + ": ",
            h("a", { href: ev.ref.url, target: "_blank", rel: "noopener" }, ev.ref.title))
        )
      );
      if (openIndex === i) details.setAttribute("open", "");
      list.appendChild(h("li", { class: "timeline-item" }, details));
    });
  }

  function openEvent(i) {
    activeEra = "all";
    drawFilters();
    drawTimeline(i);
    const el = document.getElementById("ev-" + i);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
  }

  WV.searchProviders.push(function (q) {
    const out = [];
    events.forEach(function (ev, i) {
      if (out.length >= 5) return;
      if ((ev.title + " " + ev.dateLabel + " " + ev.text).toLowerCase().indexOf(q) !== -1) {
        out.push({ type: "sr_event", label: ev.dateLabel + " – " + ev.title, go: function () { openEvent(i); } });
      }
    });
    return out;
  });

  WV.onLangChange.push(function () { drawFilters(); drawTimeline(); });

  drawFilters();
  drawTimeline();
})();

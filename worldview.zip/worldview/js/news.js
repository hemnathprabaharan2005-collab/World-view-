/* WORLDVIEW - current news
   Source: GDELT DOC 2.0 API (free, no key). Headlines are machine-collected,
   so every item is labelled "Developing" and links to its original source. */
(function () {
  "use strict";
  const t = WV.t, h = WV.h;

  const TOPICS = {
    politics: "(politics OR diplomacy OR government OR election) sourcelang:english",
    business: "(economy OR business OR trade OR markets) sourcelang:english",
    science:  "(science OR technology OR research OR space) sourcelang:english",
    world:    "(summit OR conflict OR disaster OR treaty) sourcelang:english"
  };
  const ORDER = ["politics", "business", "science", "world"];

  const tabs = document.getElementById("news-tabs");
  const status = document.getElementById("news-status");
  const list = document.getElementById("news-list");

  let active = "politics";
  let state = "idle";        // idle | loading | error | ready
  const cache = {};          // topic -> { time, items }
  let lastRequest = 0;       // GDELT asks for about 1 request per 5 seconds

  function drawTabs() {
    tabs.innerHTML = "";
    ORDER.forEach(function (key) {
      tabs.appendChild(h("button", {
        type: "button", role: "tab",
        class: "chip" + (key === active ? " active" : ""),
        "aria-selected": key === active ? "true" : "false",
        onclick: function () { select(key); }
      }, t("tab_" + key)));
    });
  }

  // GDELT dates look like 20261112T093000Z
  function parseSeenDate(s) {
    const m = /^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})Z$/.exec(s || "");
    if (!m) return null;
    return new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6]));
  }

  function drawList(items) {
    list.innerHTML = "";
    items.forEach(function (a) {
      const d = parseSeenDate(a.seendate);
      const dateText = d ? d.toLocaleString(WV.langTag(), { dateStyle: "medium", timeStyle: "short" }) : "";
      let safeUrl = "#";
      try { const u = new URL(a.url); if (u.protocol === "http:" || u.protocol === "https:") safeUrl = u.href; } catch (e) { /* bad url */ }

      list.appendChild(h("li", { class: "news-item" },
        h("a", { href: safeUrl, target: "_blank", rel: "noopener noreferrer", class: "news-title" }, a.title || safeUrl),
        h("p", { class: "news-meta" },
          h("span", { class: "badge badge-developing" }, t("badge_developing")),
          " " + t("news_by") + ": " + (a.domain || "?"),
          dateText ? " · " + t("news_published") + ": " + dateText : ""
        )
      ));
    });
  }

  function refresh() {
    list.innerHTML = "";
    if (state === "loading") status.textContent = t("news_loading");
    else if (state === "error") status.textContent = t("news_error");
    else if (state === "ready" && cache[active] && !cache[active].items.length) status.textContent = t("news_empty");
    else status.textContent = "";
    if (state === "ready" && cache[active]) drawList(cache[active].items);
  }

  function load(topic) {
    const hit = cache[topic];
    if (hit && Date.now() - hit.time < 5 * 60 * 1000) { state = "ready"; refresh(); return; }

    state = "loading";
    refresh();

    // be polite to the free service: wait if the last request was under 5 seconds ago
    const wait = Math.max(0, 5200 - (Date.now() - lastRequest));
    setTimeout(function () {
      lastRequest = Date.now();
      const url = "https://api.gdeltproject.org/api/v2/doc/doc?query=" + encodeURIComponent(TOPICS[topic]) +
                  "&mode=artlist&maxrecords=20&format=json&sort=datedesc&timespan=24h";
      fetch(url)
        .then(function (res) {
          if (!res.ok) throw new Error("HTTP " + res.status);
          return res.text();
        })
        .then(function (text) {
          let data;
          try { data = JSON.parse(text); } catch (e) { throw new Error("service returned a message instead of data"); }
          const seen = {};
          const items = (data.articles || []).filter(function (a) {
            const key = (a.title || "").toLowerCase();
            if (!a.title || !a.url || seen[key]) return false;
            seen[key] = true;
            return true;
          }).slice(0, 12);
          cache[topic] = { time: Date.now(), items: items };
          if (topic === active) { state = "ready"; refresh(); }
        })
        .catch(function (err) {
          console.warn("News failed to load:", err);
          if (topic === active) { state = "error"; refresh(); }
        });
    }, wait);
  }

  function select(topic) {
    if (!TOPICS[topic]) return;
    active = topic;
    drawTabs();
    load(topic);
  }

  WV.selectNewsTab = select;
  WV.onLangChange.push(function () { drawTabs(); refresh(); });

  drawTabs();

  // Load headlines only when the news section scrolls into view (saves data)
  const section = document.getElementById("news");
  if ("IntersectionObserver" in window) {
    const obs = new IntersectionObserver(function (entries) {
      if (entries[0].isIntersecting) { obs.disconnect(); load(active); }
    }, { rootMargin: "200px" });
    obs.observe(section);
  } else {
    load(active);
  }
})();
